package Week_3;

public class B extends A{
	public void f2()
	{
		System.out.println("B---f2");
	}
	public void all()
	{
		f1();
		f2();
	}

}
