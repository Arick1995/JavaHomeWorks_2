package Week_3;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b = new B();
		b.f1();
		b.f2();
		b.all();
		
		A a = new A();
		a.f1();
		a.f2();
		//a.all();
		
		if(a instanceof B)
		{
			System.out.println("�O");
		}

	}

}
