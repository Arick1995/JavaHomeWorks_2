package Week_3;

public class GenericMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer[] intArray = {3, 1, 4, 4, 9};		
		Double[] doubleArray = {3.14, 0.875, 9.2, 8.2};
		Character[] charArray = {'b', 'i', 'a', 'n', 'y', 'u', 'a', 'n'};
		
		pArray(intArray);
		System.out.println();
		pArray(doubleArray);
		System.out.println();
		pArray(charArray);

	}
	
	public static <T> void pArray(T[] array)
	{
		for(T emt : array)
		{
			System.out.printf("%s\t", emt);
		}
	}

}
