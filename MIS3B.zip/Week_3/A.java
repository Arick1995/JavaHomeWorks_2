package Week_3;

public class A {
	public void f1()
	{
		System.out.println("A---f1");
	}
	public void f2()
	{
		System.out.println("A---f2");
	}
}
