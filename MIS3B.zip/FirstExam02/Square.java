package FirstExam02;

public class Square extends Shape{
	private int side;
	
	public Square(int s)
	{
		this.side = s;
	}
	
	public double area() {
		return Math.pow((double)side, 2);
	}

	public double perimeter() {
		return (double)side * 4;
	}

}
