package FirstExam02;

public class Circle extends Shape{
	private int radius;

	public Circle(int r)
	{
		this.radius = r;
	}
	
	public double area() {
		return Math.pow((double)radius, 2)*Math.PI;
	}

	public double perimeter() {
		return (double)radius * 2 * Math.PI;
	}
}
