package FirstExam02;

import java.text.DecimalFormat;

public class shape_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DecimalFormat df = new DecimalFormat("#.##");
		
		Shape f1 = new Circle(10);  // 10 is the radius of circle f1
	    Shape f2 = new Square(8);  // 8 is the length of a side of square f2
	    
	    System.out.println("Circle area = " + df.format(f1.area()) + " ,perimeter = " + df.format(f1.perimeter()));
	    System.out.println("Square area = " + df.format(f2.area()) + " ,perimeter = " + df.format(f2.perimeter()));
	}

}
