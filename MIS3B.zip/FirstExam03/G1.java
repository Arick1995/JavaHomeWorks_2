package FirstExam03;

public abstract class G1 {
	private int a = 3;
	protected int b = 4;
	public int geta( )
	{
		return a; 
	}
	public abstract void printa( );


}
