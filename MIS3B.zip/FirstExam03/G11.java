package FirstExam03;

public class G11 extends G1{

	public void printa() {
		System.out.println("a = " + geta() + " ,b = " + b);
	}

}
