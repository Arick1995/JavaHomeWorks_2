package FirstExam03;

public class polymorfism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		G1 t = new G11();
		t.printa();
	}

}
