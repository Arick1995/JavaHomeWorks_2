package Week_5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB_MainClass {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String connUrl = "jdbc:sqlserver://localhost:1433;integratedSecurity=true;databaseName=JavaConnect";
		Connection conn = DriverManager.getConnection(connUrl); 
		
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM Student");
		
		while(rs.next()) 
		{
			System.out.println("ID = " + rs.getInt("ID"));
			System.out.println("Name = " + rs.getString("Name")); 
			System.out.println("Age = " + rs.getInt("Age")); 
		}
		
		rs.close();
		
		String query = "Insert into Student values (?,?,?)";
		
		PreparedStatement pstmt = conn.prepareStatement(query);
		pstmt.setInt(1, 3);
		pstmt.setString(2, "Andy");
		pstmt.setInt(3, 26);
		pstmt.executeUpdate();
		pstmt.close();
		
		conn.close();

	}

}
