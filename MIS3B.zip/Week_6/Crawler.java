package Week_6;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Method;
import org.jsoup.nodes.Document;

public class Crawler {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Connection.Response response = Jsoup.connect("https://www.ptt.cc/ask/over18").userAgent("Mozilla").data("yes","yes").method(Method.POST).execute();
		String cookie = response.cookie("over18"); 
		
		Document doc = Jsoup.connect("https://www.ptt.cc/bbs/Gossiping/index.html").userAgent("Mozilla").cookie("over18", cookie).get();
		
		for(int i=0 ; i<5 ; i++)
		{
			String title = doc.select("div[class=r-ent]>div[class=title]>a").get(i).text();
			System.out.println(title);
		}

	}

}
