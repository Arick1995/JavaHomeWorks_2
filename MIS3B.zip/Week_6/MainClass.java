package Week_6;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jsoup.Connection;
import org.jsoup.Connection.Method;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class MainClass {

	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
		Date date = new Date();
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String connUrl = "jdbc:sqlserver://localhost:1433;integratedSecurity=true;databaseName=PTTCrawler";
		java.sql.Connection conn = DriverManager.getConnection(connUrl); 
		
		Connection.Response response = Jsoup.connect("https://www.ptt.cc/ask/over18").userAgent("Mozilla").data("yes","yes").method(Method.POST).execute();
		String cookie = response.cookie("over18"); 
		
		Document doc = Jsoup.connect("https://www.ptt.cc/bbs/Gossiping/index.html").userAgent("Mozilla").cookie("over18", cookie).get();
		
		String query = "Insert into PTT values (?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(query);
		
		for(int i=0 ; i<5 ; i++)
		{
			String title = doc.select("div[class=r-ent]>div[class=title]>a").get(i).text();
			System.out.println(title);
			pstmt.setInt(1, i+1);
			pstmt.setString(2, sdf.format(date));
			pstmt.setString(3, title);
			pstmt.executeUpdate();
		}
		pstmt.close();		
		conn.close();
	}

}
